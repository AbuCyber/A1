/* generated file, don't edit. */


package de.tutao.tutanota.ipc

import kotlinx.serialization.*
import kotlinx.serialization.json.*


/**
 * Key definition for shortcuts.
 */
@Serializable
data class NativeKey(
	val code: Int,
	val name: String,
)
