package de.tutao.tutanota

import android.content.Intent

class ActivityResult(val resultCode: Int, val data: Intent?)