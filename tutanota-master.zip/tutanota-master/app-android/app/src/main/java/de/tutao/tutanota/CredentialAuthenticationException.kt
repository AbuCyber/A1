package de.tutao.tutanota

class CredentialAuthenticationException(message: String) : Exception(message)