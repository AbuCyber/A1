package de.tutao.tutanota.push

object ResponseCodes {
	const val NOT_AUTHENTICATED = 401
	const val NOT_AUTHORIZED = 403
}