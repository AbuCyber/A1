package de.tutao.tutanota

class CancelledError : Exception()