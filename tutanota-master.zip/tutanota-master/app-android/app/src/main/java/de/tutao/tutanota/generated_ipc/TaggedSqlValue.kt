/* generated file, don't edit. */


package de.tutao.tutanota.ipc
typealias TaggedSqlValue = de.tutao.tutanota.offline.TaggedSqlValue
