/* generated file, don't edit. */


package de.tutao.tutanota.ipc
typealias ContactAddressType = de.tutao.tutanota.ContactAddressType
