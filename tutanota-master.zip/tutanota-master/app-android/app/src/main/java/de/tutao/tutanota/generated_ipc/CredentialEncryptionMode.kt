/* generated file, don't edit. */


package de.tutao.tutanota.ipc
typealias CredentialEncryptionMode = de.tutao.tutanota.credentials.CredentialEncryptionMode
