// Functions which we added to OpenSSL because OpenSSL did not support them out of the box.

int RSA_padding_add_PKCS1_OAEP_SHA256(unsigned char *to, int tlen, const unsigned char *from, int flen, const unsigned char *param, int plen);

int RSA_padding_check_PKCS1_OAEP_SHA256(unsigned char *to, int tlen, const unsigned char *from, int flen, int num, const unsigned char *param, int plen);


